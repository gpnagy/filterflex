<?php
/**
 * Adds the admin menu.
 *
 * @return void
 */
function filterflex_add_admin_menu() {
    add_menu_page(
        __( 'FilterFlex', 'filterflex' ),
        __( 'FilterFlex', 'filterflex' ),
        'manage_options',
        'filterflex',
        'filterflex_admin_page_contents',
        'dashicons-filter',
        50
    );
}

add_action( 'admin_menu', 'filterflex_add_admin_menu' );

/**
 * Outputs the admin page contents.
 *
 * @return void
 */
function filterflex_admin_page_contents() {
    ?>
    <div class="wrap">
        <h1><?php _e( 'FilterFlex', 'filterflex' ); ?></h1>

        <form id="filterflex-admin-form">
            <label for="filterflex-filterable-element"><?php _e( 'Filterable Element:', 'filterflex' ); ?></label>
            <select id="filterflex-filterable-element" name="filterable_element">
                <?php
                // Get filterable elements from the filter application class
                $filter_application = new FilterFlex_Filter_Application();
                $filterable_elements = $filter_application->get_filterable_elements();
                
                foreach ( $filterable_elements as $key => $element ) {
                    echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $element['label'] ) . '</option>';
                }
                ?>
            </select>
            <br><br>

            <label for="filterflex-post-type"><?php _e( 'Post Type:', 'filterflex' ); ?></label>
            <select id="filterflex-post-type" name="context_settings[post_type]">
                <option value="post"><?php _e( 'Post', 'filterflex' ); ?></option>
                <option value="page"><?php _e( 'Page', 'filterflex' ); ?></option>
                <!-- Add more options here -->
            </select>
            <br><br>

            <button type="button" id="filterflex-save-button" class="button button-primary"><?php _e( 'Save Filter', 'filterflex' ); ?></button>
        </form>
    </div>
    <?php
}
