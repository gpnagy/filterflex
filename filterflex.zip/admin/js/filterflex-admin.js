// admin/js/filterflex-admin.js
jQuery(document).ready(function($) {

    // --- Metabox Toggle ---
    $('.filterflex-metabox-header').on('click', function() {
        const $header = $(this);
        const $content = $header.next('.filterflex-metabox-content');
        const $arrow = $header.find('.filterflex-toggle-arrow');
        const $metabox = $header.closest('.filterflex-metabox');

        $content.slideToggle(200, function() { // Add slide animation
            if ($content.is(':visible')) {
                $arrow.html('▲'); // Up arrow
                $metabox.removeClass('closed');
            } else {
                $arrow.html('▼'); // Down arrow
                $metabox.addClass('closed');
            }
        });
    });

    // --- Location Rules ---
    const rulesContainer = $('#filterflex-location-rules-container');
    let groupIndex = rulesContainer.find('.filterflex-rule-group').length -1; // Start index based on existing groups

    // Function to update value dropdown options based on selected parameter using AJAX
    function updateValueOptions($row, initialLoad = false) {
        const param = $row.find('.filterflex-rule-param').val();
        const $valueSelect = $row.find('.filterflex-rule-value');
        // Read the saved value from the data attribute on initial load
        const savedVal = initialLoad ? $valueSelect.data('saved-value') : null;

        $valueSelect.empty().hide().prop('disabled', false); // Clear, hide, and ensure it's enabled

        if (!param) {
            $valueSelect.append($('<option>', { value: '', text: filterFlexData.i18n?.selectParam || '-- Select Parameter First --' }));
            // Don't show if no param selected
            // $valueSelect.show();
            return; // Exit if no parameter is selected
        }

        if (!param) {
            $valueSelect.append($('<option>', { value: '', text: filterFlexData.i18n?.selectParam || '-- Select Parameter First --' }));
            return; // Exit if no parameter is selected
        }

        // Add loading indicator
        $valueSelect.append($('<option>', { value: '', text: filterFlexData.i18n?.loading || 'Loading...' })).show();

        // Make AJAX request
        $.ajax({
            url: filterFlexData.ajax_url,
            type: 'POST',
            data: {
                action: 'filterflex_get_location_values',
                nonce: filterFlexData.ajax_nonce, // Use the specific nonce
                param: param
            },
            success: function(response) {
                $valueSelect.empty(); // Clear loading indicator

                if (response.success && response.data.values && Object.keys(response.data.values).length > 0) {
                    $valueSelect.append($('<option>', { value: '', text: filterFlexData.i18n?.selectValue || '-- Select Value --' }));
                    $.each(response.data.values, function(value, label) {
                        $valueSelect.append($('<option>', {
                            value: value,
                            text: label
                        }));
                    });

                    // Try to re-select the original saved value if it exists (only on initial load)
                    if (initialLoad && savedVal !== null && response.data.values.hasOwnProperty(savedVal)) {
                        $valueSelect.val(savedVal);
                    } else {
                         $valueSelect.val(''); // Select default if no saved value or not found
                    }
                     $valueSelect.show();
                } else {
                    // No options returned or error
                    $valueSelect.append($('<option>', { value: '', text: filterFlexData.i18n?.noOptions || '-- N/A --' }));
                    // Keep it hidden or show N/A? Let's show N/A but keep it disabled-like
                     $valueSelect.show().prop('disabled', true); // Visually indicate no options
                 }
             },
             error: function(jqXHR, textStatus, errorThrown) {
                 // Log the actual error details
                 console.error('FilterFlex AJAX Error:', textStatus, errorThrown, jqXHR.responseText);
                 $valueSelect.empty();
                 // Display a user-friendly error message
                 const errorMsg = filterFlexData.i18n?.ajaxError || 'Error loading options';
                 $valueSelect.append($('<option>', { value: '', text: errorMsg })).show().prop('disabled', true);
             },
             complete: function() {
                 // Re-enable dropdown if it was disabled
                 if ($valueSelect.prop('disabled')) {
                     // Only re-enable if options were actually loaded successfully
                     if ($valueSelect.find('option').length > 1) { // More than just the default/error option
                         $valueSelect.prop('disabled', false);
                     }
                 }
                 // Clear the saved value data attribute after using it on initial load
                 // Although it might not be strictly necessary to remove it
                 // if (initialLoad) {
                 //    $valueSelect.removeData('saved-value');
                 // }
            }
        });
    }

    // Initial population of value dropdowns on page load using AJAX
    rulesContainer.find('.filterflex-rule-row').each(function() {
        const $row = $(this);
        // The saved value is now in 'data-saved-value', read by updateValueOptions
        updateValueOptions($row, true); // Pass true for initialLoad
    });

    // Change param dropdown - update value options via AJAX
    rulesContainer.on('change', '.filterflex-rule-param', function() {
        const $row = $(this).closest('.filterflex-rule-row');
        updateValueOptions($row, false); // Pass false for subsequent updates
    });

    // Add Rule (AND)
    rulesContainer.on('click', '.filterflex-add-rule', function() {
        const $group = $(this).closest('.filterflex-rule-group');
        const $lastRow = $group.find('.filterflex-rule-row:last');
        const $newRow = $lastRow.clone();
        const groupIdx = $group.index();
        const newRowIndex = $group.find('.filterflex-rule-row').length;

        // Update name attributes and clear values for the new row
        $newRow.find('select, input').each(function() {
            const name = $(this).attr('name').replace(/\[\d+\]\[\d+\]/g, '[' + groupIdx + '][' + newRowIndex + ']');
            $(this).attr('name', name).val('');
        });

        // Clear and hide the value dropdown initially
        $newRow.find('.filterflex-rule-value').empty().hide();
        $newRow.appendTo($group);
        // updateValueOptions($newRow); // Don't update yet, wait for param selection
    });

     // Remove Rule
     rulesContainer.on('click', '.filterflex-remove-rule', function() {
         const $row = $(this).closest('.filterflex-rule-row');
         const $group = $row.closest('.filterflex-rule-group');
         if ($group.find('.filterflex-rule-row').length > 1) {
             $row.remove();
         } else {
             // If it's the last rule in the group, remove the whole group? Or just clear it?
             // For now, just don't allow removing the last rule in a group if it's not the only group
             if (rulesContainer.find('.filterflex-rule-group').length > 1) {
                 $group.remove();
             } else {
                 alert('Cannot remove the last rule.'); // Or clear the fields
             }
         }
     });

    // Add Rule Group (OR)
    $('.filterflex-add-rule-group').on('click', function() {
        groupIndex++;
        const $firstGroup = rulesContainer.find('.filterflex-rule-group:first');
        const $newGroup = $('<div class="filterflex-rule-group"></div>');
        const $newRow = $firstGroup.find('.filterflex-rule-row:first').clone();

        // Update name attributes and clear values for the new row in the new group
        $newRow.find('select, input').each(function() {
            const name = $(this).attr('name').replace(/\[\d+\]\[\d+\]/g, '[' + groupIndex + '][0]');
            $(this).attr('name', name).val('');
        });

         // Clear and hide the value dropdown initially
        $newRow.find('.filterflex-rule-value').empty().hide();
        $newRow.appendTo($newGroup);
        $newGroup.appendTo(rulesContainer);
        // updateValueOptions($newRow); // Don't update yet, wait for param selection
    });

    // --- Output Builder ---
    const $builderVisualInput = $('#filterflex-builder-visual-input');
    const $patternHiddenInput = $('#filterflex-output-pattern-input');
    const $availableTagsContainer = $('.filterflex-available-tags .filterflex-tags-list');

    // Function to create a tag element for the builder
    function createBuilderTagElement(tag, label) {
        const $tagElement = $('<span>')
            .addClass('filterflex-tag-item filterflex-builder-item')
            .attr('data-tag', tag)
            .text(label);

        // Make the {filtered_element} tag non-removable
        if (tag === '{filtered_element}') {
            $tagElement.addClass('non-removable');
            // Optionally, don't add the remove button, or disable it visually
            // $tagElement.append('<span class="filterflex-remove-item disabled">×</span>');
        } else {
            $tagElement.append('<span class="filterflex-remove-item">×</span>'); // Add remove button only for others
        }
        return $tagElement;
    }

    // Function to create a static text input element for the builder
    function createBuilderTextInputElement(value = '') {
        return $('<input>')
            .attr('type', 'text')
            .addClass('filterflex-static-text-input filterflex-builder-item')
            .attr('placeholder', 'Type static text...')
            .val(value)
            .append('<span class="filterflex-remove-item">×</span>'); // Add remove button (might need wrapper)
            // Wrap input for easier removal styling/logic
        // return $('<span>').addClass('filterflex-text-input-wrapper filterflex-builder-item')
        //     .append(input)
        //     .append('<span class="filterflex-remove-item">×</span>');
    }

    // Function to update the hidden input with the structured pattern (JSON)
    function updateHiddenPatternInput() {
        const patternData = [];
        $builderVisualInput.find('.filterflex-builder-item').each(function() {
            const $item = $(this);
            if ($item.hasClass('filterflex-tag-item')) {
                patternData.push({ type: 'tag', value: $item.data('tag') });
            } else if ($item.hasClass('filterflex-static-text-input')) {
                // If using wrapper: const value = $item.find('input').val();
                const value = $item.val();
                // Only add non-empty text inputs to the pattern
                if (value.trim() !== '') {
                    patternData.push({ type: 'text', value: value });
                }
            }
            // else if ($item.hasClass('filterflex-text-input-wrapper')) { // If using wrapper
            //     const value = $item.find('input').val();
            //     if (value.trim() !== '') {
            //         patternData.push({ type: 'text', value: value });
            //     }
            // }
        });
        $patternHiddenInput.val(JSON.stringify(patternData));
        // console.log("Updated Pattern:", $patternHiddenInput.val()); // For debugging
        updatePreview(); // Update preview whenever pattern changes
    }

    // Function to render the visual builder from the saved structured pattern (JSON)
    function renderBuilderFromPattern(patternJson) {
        $builderVisualInput.empty();
        let patternData = [];
        try {
            patternData = JSON.parse(patternJson || '[]');
        } catch (e) {
            console.error("Error parsing saved pattern JSON:", e);
            patternData = []; // Reset to empty on error
        }

        if (!Array.isArray(patternData)) {
             console.error("Saved pattern is not an array:", patternData);
             patternData = [];
        }


        patternData.forEach(item => {
            if (item.type === 'tag') {
                // Find the label for the tag
                let label = item.value.substring(1, item.value.length - 1); // Default label
                $availableTagsContainer.find('.filterflex-tag-item').each(function(){
                    if($(this).data('tag') === item.value){
                         label = $(this).text();
                         return false; // exit loop
                    }
                });
                $builderVisualInput.append(createBuilderTagElement(item.value, label));
            } else if (item.type === 'text') {
                $builderVisualInput.append(createBuilderTextInputElement(item.value));
            }
        });

        // Add an initial empty text input if the builder is empty, for usability
        if ($builderVisualInput.children().length === 0) {
             $builderVisualInput.append(createBuilderTextInputElement());
        }
    }

    // --- Drag and Drop & Sortable ---
    // Make available tags draggable
    $availableTagsContainer.find('.draggable-tag').draggable({
        helper: 'clone', // Clone the tag when dragging
        cursor: 'grabbing',
        revert: 'invalid', // Revert if not dropped on a valid target
        connectToSortable: '#filterflex-builder-visual-input', // Connect to the sortable builder
        start: function(event, ui) {
            $(ui.helper).css('z-index', 100); // Ensure helper is on top
        }
    });

    // Make the builder area sortable and droppable
    $builderVisualInput.sortable({
        placeholder: 'filterflex-sortable-placeholder', // CSS class for placeholder
        cursor: 'move',
        items: '.filterflex-builder-item', // Only allow sorting of builder items
        tolerance: 'pointer',
        start: function(event, ui) {
            ui.placeholder.height(ui.item.outerHeight());
            ui.placeholder.width(ui.item.outerWidth());
        },
        receive: function(event, ui) { // Handle drop from available tags
            const $originalTag = $(ui.item); // This is the original tag from the available list
            const tag = $originalTag.data('tag');
            const label = $originalTag.text();
            const $newTagElement = createBuilderTagElement(tag, label);

            // Replace the dragged helper/original with the new builder element
            $(ui.helper).replaceWith($newTagElement);

            // Add empty text inputs around the new tag if needed
            addTextInputsAround($newTagElement);

            updateHiddenPatternInput();
        },
        update: function(event, ui) { // Handle reordering within the builder
            // Ensure text inputs are correctly placed after sorting
            ensureTextInputsBetweenItems();
            updateHiddenPatternInput();
        }
    });

    // Make the builder area droppable
    $builderVisualInput.droppable({ // Make it droppable for the draggable tags
        accept: '.draggable-tag',
        hoverClass: 'drag-over', // Use the CSS class for highlighting
        drop: function(event, ui) {
            // The 'receive' event in sortable handles the actual element creation
        }
    });

    // Function to add empty text inputs before/after an item if needed
    function addTextInputsAround($item) {
        if (!$item.prev().length || $item.prev().hasClass('filterflex-tag-item')) {
            $item.before(createBuilderTextInputElement());
        }
        if (!$item.next().length || $item.next().hasClass('filterflex-tag-item')) {
            $item.after(createBuilderTextInputElement());
        }
        // Clean up consecutive text inputs
        cleanupConsecutiveTextInputs();
    }

     // Function to ensure there's always a text input between tags and at ends
     function ensureTextInputsBetweenItems() {
         const $items = $builderVisualInput.find('.filterflex-builder-item');
         if ($items.length === 0) {
             $builderVisualInput.append(createBuilderTextInputElement());
             return;
         }

         // Ensure text input at the beginning if first item is a tag
         if ($items.first().hasClass('filterflex-tag-item')) {
             $items.first().before(createBuilderTextInputElement());
         }

         // Ensure text input at the end if last item is a tag
         if ($items.last().hasClass('filterflex-tag-item')) {
             $items.last().after(createBuilderTextInputElement());
         }

         // Ensure text input between consecutive tags
         $items.each(function(index) {
             const $currentItem = $(this);
             const $nextItem = $items.eq(index + 1);
             if ($currentItem.hasClass('filterflex-tag-item') && $nextItem.hasClass('filterflex-tag-item')) {
                 $currentItem.after(createBuilderTextInputElement());
             }
         });

         cleanupConsecutiveTextInputs();
     }

     // Function to merge or remove consecutive text inputs
     function cleanupConsecutiveTextInputs() {
         let $previousInput = null;
         $builderVisualInput.find('.filterflex-static-text-input').each(function() {
             const $currentInput = $(this);
             if ($previousInput) {
                 // Merge values and remove the current one if previous exists
                 const prevVal = $previousInput.val();
                 const currentVal = $currentInput.val();
                 $previousInput.val(prevVal + currentVal);
                 $currentInput.remove();
                 // Don't update $previousInput, continue checking against the merged one
             } else {
                 // If the input is empty and it's not the only item, remove it
                 if ($currentInput.val().trim() === '' && $builderVisualInput.find('.filterflex-builder-item').length > 1) {
                      // Check if it's between two tags or at the end before a tag, etc.
                      // Simplified: remove if empty and not the only element
                      // $currentInput.remove();
                      // Let's keep empty inputs for now, they get filtered out in updateHiddenPatternInput
                      $previousInput = $currentInput; // Keep it as the potential previous one
                 } else {
                    $previousInput = $currentInput;
                 }
             }
         });
          // Remove empty text input if it's the very last element and not the only element
         const $lastItem = $builderVisualInput.find('.filterflex-builder-item').last();
         if ($lastItem.hasClass('filterflex-static-text-input') && $lastItem.val().trim() === '' && $builderVisualInput.find('.filterflex-builder-item').length > 1) {
            // $lastItem.remove(); // Maybe keep it for adding new tags at the end easily?
         }
     }


    // --- Builder Item Interactions ---

    // Remove item (tag or text input wrapper)
    $builderVisualInput.on('click', '.filterflex-remove-item', function(e) {
        e.stopPropagation(); // Prevent triggering other clicks on the item
        const $itemToRemove = $(this).closest('.filterflex-builder-item');
        console.log('Removing item:', $itemToRemove);
        $itemToRemove.remove();
        ensureTextInputsBetweenItems(); // Make sure structure is correct after removal
        updateHiddenPatternInput();
    });

    // Update hidden input when text inputs change
    $builderVisualInput.on('keyup change', '.filterflex-static-text-input', function() {
        // Use debounce in a real application
        updateHiddenPatternInput();
    });

    // Add a new text input when clicking in the empty space (optional usability enhancement)
    // $builderVisualInput.on('click', function(e) {
    //     if (e.target === this) { // Clicked directly on the container, not an item
    //         $(this).append(createBuilderTextInputElement());
    //         updateHiddenPatternInput();
    //     }
    // });


    // Initialize builder on page load
    if (filterFlexData.saved_output_pattern === '' || filterFlexData.saved_output_pattern === '[]') {
        renderBuilderFromPattern('[{"type":"tag", "value":"[filtered_element]"}]');
    } else {
        renderBuilderFromPattern(filterFlexData.saved_output_pattern);
    }
    ensureTextInputsBetweenItems(); // Ensure initial structure is correct


    // --- Transformations ---
    const $transContainer = $('#filterflex-transformations-container');
    let transIndex = $transContainer.find('.filterflex-transformation-row').length - 1;

    // Function to show/hide conditional inputs
    function toggleTransformationInputs($row) {
        const type = $row.find('select[name$="[type]"]').val();
        $row.find('input[name$="[search]"], input[name$="[replace]"]').toggle(type === 'search_replace');
        $row.find('input[name$="[limit]"]').toggle(type === 'limit_words');
        // Add conditions for other types
    }

    // Initial toggle for existing rows
    $transContainer.find('.filterflex-transformation-row').each(function() {
        toggleTransformationInputs($(this));
    });

     // Change transformation type
     $transContainer.on('change', 'select[name$="[type]"]', function() {
         toggleTransformationInputs($(this).closest('.filterflex-transformation-row'));
         updatePreview(); // Update preview on change
     });

      // Add Transformation
     $('.filterflex-add-transformation').on('click', function() {
         transIndex++;
         const $firstRow = $transContainer.find('.filterflex-transformation-row:first');
         // Clone the first row OR have a hidden template row
         let $newRow;
         if ($firstRow.length) {
            $newRow = $firstRow.clone();
         } else {
             // Create from scratch if none exist (better to have a template)
             $newRow = $('<div class="filterflex-transformation-row">' +
                         '<select name="filterflex_transformations['+transIndex+'][type]"><option value="">-- Select --</option>...</select>' +
                         '<input type="text" name="filterflex_transformations['+transIndex+'][search]" style="display:none;">' +
                         // ... other inputs ...
                         '<button type="button" class="button-link filterflex-remove-transformation">Remove</button>' +
                         '</div>');
         }

         // Update name attributes
         $newRow.find('select, input').each(function() {
             const name = $(this).attr('name').replace(/\[\d+\]/, '[' + transIndex + ']');
             $(this).attr('name', name);
             $(this).val(''); // Clear values
         });
         $newRow.find('input').hide(); // Hide conditional inputs initially
         $newRow.appendTo($transContainer);
     });

     // Remove Transformation
     $transContainer.on('click', '.filterflex-remove-transformation', function() {
         $(this).closest('.filterflex-transformation-row').remove();
         updatePreview();
     });

     // Update preview when transformation inputs change
     $transContainer.on('change keyup', 'input', function() {
         // Use debounce in a real app
         updatePreview();
     });


    // --- Live Preview ---
    const $previewOutput = $('#filterflex-preview-output');

    function updatePreview() {
        // 1. Get the current builder pattern from the hidden input
        const pattern = $patternHiddenInput.val();

        // 2. Get the current transformation settings
        const transformations = [];
        $transContainer.find('.filterflex-transformation-row').each(function() {
            const $row = $(this);
            const type = $row.find('select[name$="[type]"]').val();
            if (type) {
                let transformation = { type: type };
                 if (type === 'search_replace') {
                     transformation.search = $row.find('input[name$="[search]"]').val();
                     transformation.replace = $row.find('input[name$="[replace]"]').val();
                 } else if (type === 'limit_words') {
                      transformation.limit = $row.find('input[name$="[limit]"]').val();
                 }
                 // Add other types
                transformations.push(transformation);
            }
        });

        // 3. Make AJAX request to get preview data (or process client-side if possible)
        // Using AJAX is generally better as PHP handles WP data access
        $.ajax({
             url: filterFlexData.ajax_url,
             type: 'POST',
             data: {
                 action: 'filterflex_get_preview', // Need to register this AJAX action
                 nonce: filterFlexData.nonce, // Use a specific nonce for this action
                 pattern: pattern,
                 transformations: transformations,
                 // Optionally pass sample post ID or context
             },
             beforeSend: function() {
                  $previewOutput.html('<i>Loading preview...</i>');
             },
             success: function(response) {
                 if (response.success && response.data) {
                     $previewOutput.html(response.data.preview || '<i>Preview unavailable</i>');
                 } else {
                     // Handle cases where success is false or data is missing
                     $previewOutput.html('<i>Error generating preview.</i>');
                     // Check if data and message exist before logging
                     const errorMessage = response.data?.message || 'Unknown error';
                     console.error('Preview Error:', errorMessage, response);
                 }
             },
             error: function(jqXHR, textStatus, errorThrown) {
                 $previewOutput.html('<i>AJAX error loading preview.</i>');
                 console.error('Preview AJAX Error:', textStatus, errorThrown);
             }
         });
    }

    // Initial preview update on load
    updatePreview();

});
